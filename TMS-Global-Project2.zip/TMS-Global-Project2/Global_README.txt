URL of prototype files (Google Drive)
https://drive.google.com/drive/folders/1KHTCbZeqAjEm0tjLiS2R8_GUC-VQKF5_?usp=sharing

URL Group prototype web hosting address
http://tms-global.infinityfreeapp.com/index.php
http://tmsglobal.lovestoblog.com/index.php

Username and password of web hosting account
username: dedreelai99@gmail.com
password: Global_123