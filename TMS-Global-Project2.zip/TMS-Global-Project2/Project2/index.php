<?php

include 'config.php';

session_start();
if(isset($_SESSION['user_id'])){
  $user_id = $_SESSION['user_id'];
}else{
  $user_id =0;
}


if(isset($_POST['add_to_cart'])){

  if(!isset($_SESSION['user_id'])){
     header('location:login.php');
  }

   $product_name = $_POST['product_name'];
   $product_brand = $_POST['product_brand'];
   $product_description = $_POST['product_description'];
   $product_price = $_POST['product_price'];
   $product_plan = $_POST['product_plan'];
   $product_image = $_POST['product_image'];
   $product_quantity = $_POST['product_quantity'];

   $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($check_cart_numbers) > 0){
      $message[] = 'already added to cart!';
   }else{
      mysqli_query($conn, "INSERT INTO `cart`(user_id, name, brand, description, price, plan, quantity, image) VALUES('$user_id', '$product_name', '$product_brand', '$product_description', '$product_price', '$product_plan', '$product_quantity', '$product_image')") or die('query failed');
      $message[] = 'product added to cart!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'header.php'; ?>

<section class="home">

   <div class="content">
     <img src="img/ling-face.png" alt="">
      <h3>The UK's Craziest Car Leasing Website!.</h3>
      <a href="about.php" class="white-btn">discover more</a>
   </div>

</section>

<section class="products">

   <h1 class="title">Our Best Selling Car Leasing Deals!</h1>
   <div class="box-container">
      <?php
         $select_products = mysqli_query($conn, "SELECT * FROM `products` LIMIT 6") or die('query failed');
         if(mysqli_num_rows($select_products) > 0){
            while($fetch_products = mysqli_fetch_assoc($select_products)){
      ?>
     <form action="" method="post" class="box">
      <img class="image" src="uploaded_img/<?php echo $fetch_products['image']; ?>" alt="">
      <div class="name"><?php echo $fetch_products['name']; ?></div>
      <div class="description"><?php echo $fetch_products['description']; ?></div>
      <div class="price">&#163;<?php echo $fetch_products['price']; ?>/mth</div>
      <div class="plan"><?php echo $fetch_products['plan']; ?></div>
      <input type="hidden" name="product_quantity" value="1" class="qty">
      <input type="hidden" name="product_name" value="<?php echo $fetch_products['name']; ?>">
      <input type="hidden" name="product_brand" value="<?php echo $fetch_products['brand']; ?>">
      <input type="hidden" name="product_description" value="<?php echo $fetch_products['description']; ?>">
      <input type="hidden" name="product_price" value="<?php echo $fetch_products['price']; ?>">
      <input type="hidden" name="product_plan" value="<?php echo $fetch_products['plan']; ?>">
      <input type="hidden" name="product_image" value="<?php echo $fetch_products['image']; ?>">
      <input type="submit" value="add to cart" name="add_to_cart" class="btn">
     </form>
      <?php
         }
      }else{
         echo '<p class="empty">no products added yet!</p>';
      }
      ?>
   </div>

</section>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="img/full-price.jpg" alt="">
      </div>

      <div class="content">
         <h3>Full Price List</h3>
         <p>One of the best websites ever made is for a car-leasing company in England, LINGsCARS. It's a work of art ... and she leases tons of cars</p>
         <a href="shop.php" class="btn">see more</a>
      </div>

   </div>

   <div class="flex">
     <div class="image">
        <img src="img/business-deal.jpg" alt="" height="250">
     </div>

     <div class="content">
        <h3>Short term bussines</h3>
        <p>Business Customers Only: This deal is only available to business customers.</p>
        <a href="bussines.php" class="btn">see more</a>
     </div>
   </div>
   <div class="flex">
     <div class="image">
        <img src="img/low-credit.jpg" alt="" height="250">
     </div>

     <div class="content">
        <h3>Low Credit Deals</h3>
        <p>Car was registered in 2020 on a 70 plate. Has 6000 miles on the clock. Will consider applications with poor credit. Scotland delivery chargeable (can be added to monthly rentals)</p>
        <a href="low_credit.php" class="btn">see more</a>
     </div>
   </div>

</section>

<section class="home-contact">

   <div class="content">
      <h3>have any questions?</h3>
      <p>I treat customers like adults, not like idiots.</p>
      <a href="contact.php" class="white-btn">contact us</a>
   </div>

</section>





<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
