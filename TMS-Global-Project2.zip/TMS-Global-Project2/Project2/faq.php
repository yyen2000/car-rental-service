<?php

include 'config.php';

session_start();
if(isset($_SESSION['user_id'])){
  $user_id = $_SESSION['user_id'];
}else{
  $user_id =0;
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device=-width, intial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/faq.css">
    <title>FAQ's</title>
  </head>

  <body>
    <?php include 'header.php'; ?>

    <h2 class="product-category">Frequently Asked Question</h2>

    <div class="centerplease">Car Delivery</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question1" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question1" class="question">
          How do I arrange delivery?
        </label>
        <div class="answers">
          You ask me to tell you about the delivery process? After your new car arrives in stock and all the finance paperwork is complete, Ling will offer you a delivery date. You can then change this to a date that suits you, if you want. Cars are usually driven to your address for free, but sometimes they will be on a truck. You need to check the car for damage.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question2" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question2" class="question">
          Can I specify a delivery date?
        </label>
        <div class="answers">
          You want to know about the delivery date? When you order your car, Ling can often give you a good guess on delivery. It's hard to be exact unless the car is already in stock. Ling will get a date when the car is due to the dealer, then we can work from that. Most customers are very happy with delivery dates, but if there's a delay, Ling can't use magic. So we are in the factory's hands.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question3" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question3" class="question">
          How is the car delivered?
        </label>
        <div class="answers">
          You ask me about delivery? After all the paperwork is done, and your car is prepared, it is delivered to you. This is free, as long as you live in a normal mainland address. Cars are usually driven on delivery, because they have wheels and they are designed to be driven. Sometimes, they might arrive on a truck or a trailer. If you want to book a trailer delivery, it usually costs slightly more.
        </div>
      </div>
    </div>

    <div class="centerplease">Car Quote</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question4" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question4" class="question">
          Explain 3+23 or 3+35?
        </label>
        <div class="answers">
          You ask me what 3 plus 35 or 3 plus 23 means? The "three" means the number of payments for the initial rental. That's how much you pay up front. You should beware that many other companies ask for 6 payments up front. The "35" or the "23" means the number of monthly payments.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question5" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question5" class="question">
          What's the best car deal?
        </label>
        <div class="answers">
          You want to know what the best car deal is? The thing is, car deals change all the time, but Ling will always have some great offers. There are always some new cars that need to be sold, by dealers. So Ling will have great deals on these models. She will suggest the best deals at the time, if you ask her. If a car deal is very cheap and you like the car, you should jump straight away. Car deals change quickly.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question6" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question6" class="question">
          Explain business & private?
        </label>
        <div class="answers">
          There are a few differences between business contracts and private contracts. The main difference is VAT. Both contracts have VAT added, but on a business contract it's calculated separately. Many businesses can claim VAT back. Private customers have the VAT included in the monthly price, because they can't claim it back. Sometimes, there may be a slightly cheaper private deal, if you get mileage or car allowance at work.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question7" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question7" class="question">
          Can I change the mileage?
        </label>
        <div class="answers">
          When you take out a contract, you decide how many miles a year you will drive. But you might move house, change job or just miscalculate. So, during the contract you can alter the mileage and change your payments to a slightly higher amount, if your mileage increases a lot. It&lsquo;s usually very flexible, but you need to talk to the finance company as soon as you notice you are doing more miles.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question8" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question8" class="question">
          Can I buy my car at the end?
        </label>
        <div class="answers">
          You want to know if you can buy the car at the end of the contract? Well, often you can. It depends on the type of the contract. But some finance companies don't allow this. However, most customers just choose another brand new car at the end of the contract, and hand the old car back. That means you always have the latest car, have full warranty, and have the new car smell.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question9" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question9" class="question">
          Can I choose any car colour?
        </label>
        <div class="answers">
          You ask about the car colour? Well, the answer is that you can have any colour that is available. But, some colours have extra charge. Ling will do her best to get you the colour you want. Most customers are very happy with colour choices. Same applies to interior trim colour choice, if there is a choice available.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question10" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question10" class="question">
          Can I add extras/options?
        </label>
        <div class="answers">
          You ask me about adding extras and options to your new car? There are two types: factory options and ones that a dealer can fit. If you ask Ling, she will discuss these and see if it's possible to add them. If a car is already built, then it is impossible to add factory options, so the order might slow down if you want these added.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question11" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question11" class="question">
          How do I find exact car spec?
        </label>
        <div class="answers">
          You ask me what's the specification of your new car? Well, car makers change the equipment on new cars all the time, as new technology comes along. So, you should look at the car manufacturer's website to check the full detail of all the stuff your new car has. If there is a piece of equipment or spec that is very important to you, you should mention it on the proposal form, and the order form and not wait until delivery. Ling will make sure that it's on the car, and if not, she'll discuss this with you.
        </div>
      </div>
    </div>

    <div class="centerplease">Car Proposal</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question12" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question12" class="question">
          Filling car proposal form?
        </label>
        <div class="answers">
          You ask about filling a proposal form on a new car? On the top right of the website menu is the link to Ling's proposal form. Or, you can click through from a car deal. Using the form is quick, and it means Ling get all the info she needs. The proposal form does not commit you to the car, it's just to get the finance approval. You can discuss your car proposal online, in LINGO, Ling's award winning customer chat.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question13" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question13" class="question">
          Will I pass new car finance?
        </label>
        <div class="answers">
          You want to know if you will pass the finance approval? Well, car leasing is mainly for private people and companies with good credit ratings. Things that will affect you badly, are late payments, CCJs and any default payments. You don't need a perfect credit rating, but it should be good. If you have poor credit, then the best thing is to speak to someone who specialises in that market, but it can get a bit expensive. There is no harm to fill in a proposal form, but please tell Ling if you have problems.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question14" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question14" class="question">
          Can someone apply for me?
        </label>
        <div class="answers">
          You ask if a family member can apply for a car for you? Maybe you have a poor credit rating or have low income, or you are young? The rules are that a family member can apply a car and you can have some use of it if you are insured. But, the person that applies for a car has the full financial responsibility for it. So, that person needs to apply for the car. There is a fine line between a husband using a wife's car, and some third party getting a new car by misrepresentation, so everyone must be very careful.
        </div>
      </div>
    </div>

    <div class="centerplease">Signed Order</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question15" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question15" class="question">
          Can I cancel an order?
        </label>
        <div class="answers">You ask about cancelling a new car order? Well, yes, of course car orders can be cancelled. But Ling orders the car on trust, where as at a dealer you would have to pay a deposit. So if the order is cancelled, especially a factory order, Ling will get surcharged by the dealer. This might cost her up to &pound;500+vat. So only place an order if you are sure you want the car.</div>
      </div>

      <div>
        <input type="checkbox" id="question16" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question16" class="question">
          Returning the car order form?
        </label>
        <div class="answers">
          After finance approval, when you want to order a car, you need to print and sign and return the car order form. Ling makes this harder than ticking a box on a webpage, because she wants to make sure you really, really want to order the car. But many people say they don't have a scanner. This is no problem as everyone has a camera. Simply take a nice photo of the signed form and upload the JPG to LINGO.
        </div>
      </div>
    </div>

    <div class="centerplease">Other Deal Info</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question17" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question17" class="question">
          Do I need maintenance plan?
        </label>
        <div class="answers">You want to know if you need to buy a maintenance contract? Most customers don't buy one, because the car is fully covered by warranty for at least 3-years, and they just pay for services. For most contracts, you need very little servicing on new cars, but when it is due you should take your car to a main dealer and pay them for the service. That's usually the cheapest and easiest way to have your new car serviced.</div>
      </div>

      <div>
        <input type="checkbox" id="question18" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question18" class="question">
          When will my tax disc arrive?
        </label>
        <div class="answers">
          You ask about tax disc on your new car? It used to be that cars had to display a tax disc from the very first day. But this has changed. The DVLA in Swansea now prints all tax discs for new cars, so it may take a week to arrive. The law allows a 14-day period. On most cars except on Mercedes, a new tax disc arrives in post to you, every year.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question19" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question19" class="question">
          Choosing new car no. plate?
        </label>
        <div class="answers">
          You ask me about your new car number plate? Usually these are issued by the DVLA in batches, so you don't get a choice. Ling will tell you your registration before delivery. Then, you can arrange your insurance. I talk about personal registration plates in a different clip.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question20" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question20" class="question">
          Adding private number plate?
        </label>
        <div class="answers">
          You ask me about putting your private number plate on your new car? This is usually possible, if your number plate is on retention. The DVLA need to make the changes, so it might take some time. If it's not possible before delivery, you can usually change your number plate to a personal plate after delivery using the finance company, but they might make a small admin charge.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question21" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question21" class="question">
          Can I short term car rental?
        </label>
        <div class="answers">
          Ling supplies cars on lease, mainly for 2 or 3 years. Occasionally she has one year deals and 4 year deals. But she doesn't do short-term car rental. Ling recommends companies like Enterprise car rental if you need a car for a few days, or a few weeks.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question22" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question22" class="question">
          Can I fit a towbar to my car?
        </label>
        <div class="answers">
          You want to know if you can fit a towbar to tow a trailer or caravan? Yes, this is fine. You should check that the car is OK to pull the size and weight of your trailer. You can get the cost included in the car deal, or you can fit a towbar after delivery. Having it fitted yourself means that at the end of the contract, you can take it off and stick it on eBay, to get some money back.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question23" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question23" class="question">
          V5 log book with Mercedes?
        </label>
        <div class="answers">
          You want to know if you get the V5 registration document? For a Mercedes car you usually get it in the post. Mercedes Benz are different to most new cars. After the first year, you will need to re-tax your Mercedes using the V5 reg doc. If you need new number plates for a trailer or caravan, Ling can make you a spare number plate free.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question24" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question24" class="question">
          V5 log book, non-Merc cars?
        </label>
        <div class="answers">
          You're asking about insurance? Well, insurance is a regulated subject, so if Ling gives advice she will go to prison. You are best to ask an insurance broker, and check the rough price before you order your new car. But usually, you just insure your car as normal, making sure all drivers are covered and making sure it's fully comprehensive cover. Ling often recommends good companies in Lingo as you discuss your new car.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question25" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question25" class="question">
          How do I insure my new car?
        </label>
        <div class="answers">
          You're asking about insurance? Well, insurance is a regulated subject, so if Ling gives advice she will go to prison. You are best to ask an insurance broker, and check the rough price before you order your new car. But usually, you just insure your car as normal, making sure all drivers are covered and making sure it's fully comprehensive cover. Ling often recommends good companies in Lingo as you discuss your new car.
        </div>
      </div>
      <div>
        <input type="checkbox" id="question26" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question26" class="question">
          What if I don't live in UK?
        </label>
        <div class="answers">
          You want to know if you can lease a car from Ling if you don't live in the UK? Maybe you live in France, or Spain, or Japan? No! No bloody people living in foreign countries! I don't care that you are EU national or an Eskimo, but you need to live in the UK, and the car needs to live in the UK. But you can take your car to Europe for holidays, no problem. Damn foreign people will need to show passport, UK or EU driving licence and lots of proofs.
        </div>
      </div>
    </div>

    <div class="centerplease">Delivered</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question27" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question27" class="question">
          Breakdown cover card?
        </label>
        <div class="answers">
          You ask me about breakdown cover card. Your new car gets free AA or RAC or the car maker's own breakdown cover. But you won't get a card... they don't issue them. Full details are with your new car, in the warranty book. Plus, you new car has full warranty for at least 3 years, so if you get any problems a dealer will fix them, free.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question28" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question28" class="question">
          Do I get breakdown cover?
        </label>
        <div class="answers">
          You ask me about breakdown cover! Yes! Your new car gets free breakdown cover from the car manufacturer, same as with any brand new car. It might be AA or RAC or the car maker's own breakdown cover. It will be for at least 1-year, but many cars have cover for the full contract, often 2 or 3 years. So, if your new car breaks down, you can just call the breakdown company and they will rescue you.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question29" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question29" class="question">
          Can I take my car abroad?
        </label>
        <div class="answers">
          You want to know if you can take the new car abroad? Yes, this is no problem. You can take your car to any normal place in Europe. You can easily apply for a form VE103 from the finance company for small charge. But you can't take it to China. So, you can enjoy your holiday in your new car!
        </div>
      </div>

      <div>
        <input type="checkbox" id="question30" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question30" class="question">
          Do I need to MOT my car?
        </label>
        <div class="answers">
          You want to know about the MOT? New cars don't need an MOT test until they are 3 years old. So, most cars won't need an MOT. You will probably hand your car back before the MOT is needed. If the MOT becomes due while you have the car, you need to take it for a test. But as it will be the first MOT, it should fly through (gettit?) with no problems.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question31" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question31" class="question">
          Do I service my new car?
        </label>
        <div class="answers">
          You will need to service your new car. This is often every year, or possibly at longer intervals. You need to take the car to a franchised dealer and pay for a normal car service. This keeps the warranty in force. The warranty means that the car dealer will fix any problems for free, in the first 3-years. So please budget for the servicing of the new car.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question32" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question32" class="question">
          What if I exceed the mileage?
        </label>
        <div class="answers">
          When you take out a contract, you decide how many miles a year you will drive. At the end of the contract, you may have driven a few more miles than the total you agreed. Extra miles you have driven are charged to you at a rate that's probably between 5p and 10p a mile. Somewhere in that region. Big expensive cars may be slightly more, per mile. So, you don't have to restrict how many miles you drive your new car.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question33" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question33" class="question">
          Who can drive my new car?
        </label>
        <div class="answers">
          You ask me who is allowed to drive your new car? The answer is that anyone can, with your permission, if they have a full driving licence and they are fully insured. The insurance is the most important thing, because you need to make sure you are not at risk, if someone else has an accident. Insurance must be fully-comprehensive. So, all your family can drive your new car!
        </div>
      </div>

      <div>
        <input type="checkbox" id="question34" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question34" class="question">
          What if I die during lease?
        </label>
        <div class="answers">
          If you die, you don't get your seat ticket refunded, and in the same way you won't get your new car refunded. But, dying can be great, because the car contract will stop immediately and your car will go back to the finance provider. This means that your loved ones, if anyone loves you, won't be left to pick up the cost of the car.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question35" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question35" class="question">
          Returning finance docs?
        </label>
        <div class="answers">
          After you order a new car from Ling, she'll send you the finance paperwork. Ling always includes a bright envelope, so you can send the signed documents back to her. She stamps the envelope with first class stamps to cover the postage, but it's really worth going to a post office and sending them back with Special Delivery. The British post office are a bit useless, like me, so Special Delivery means the envelope is guaranteed to arrive with Ling the very next day.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question36" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question36" class="question">
          Explain Ling's safety rules?
        </label>
        <div class="answers">
          Ling takes your safety in your new car very seriously. After all, she doesn't want you to crash and die, because that means you won't take another car from her in the future. She has asked me to prepare a car safety card. Here it is. It's compulsory that all customers read this and watch the safety movie, with Melissa. I recommend you keep the safety card in your new car.
        </div>
      </div>
    </div>

    <div class="centerplease">Car Return</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question37" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question37" class="question">
          Explain the end of the lease?
        </label>
        <div class="answers">
          You want to know what happens at the end of the lease? Well, you arrange collection of the car, by the finance company. This is free. But you need to check the car is in good condition. There is a guide on Ling's website. It's best if you get small damage like scratches, repaired. Otherwise the finance company might send you a bill for damage.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question38" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question38" class="question">
          Private reg back, at end?
        </label>
        <div class="answers">
          You want to know how you get your private reg plate back, at the end of the contract? If you have put a private reg plate on your new car, then the finance company will be the "nominee". You are the "grantee" and you still own the private plate. At the end of the contract, you will simply discuss with the finance company, and put your reg private plate back on retention. When you apply it to another new car, you will then change the nominee to the next new finance company.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question39" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question39" class="question">
          "Returning Customer" bribe?
        </label>
        <div class="answers">
          You ask me if a returning customer gets a discount? In most cases, Ling is happy to give you a discount, by reducing any admin fee. She will reduce the admin fee by &pound;50 each time you return for a new car, up to &pound;100. So on your second car from Ling you get &pound;50 off, your third car you get &pound;100 off. Ling wants you to come back for more cars.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question40" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question40" class="question">
          When should I arrange a replacement car?
        </label>
        <div class="answers">
          You want to know when you should begin to arrange a replacement car? Changing your existing lease car is quite easy. You simply apply for a new car and the delivery will coincide with your existing lease car going back. But some new cars can take a long time to arrive, especially if they need to be ordered at the factory. So, Ling suggests starting your new car application 3 months before your existing contract expires.
        </div>
      </div>
    </div>

    <div class="centerplease">Car Price</div><br>

    <div class="content">
      <div>
        <input type="checkbox" id="question41" name="q"  class="questions">
        <div class="plus">+</div>
        <label for="question41" class="question">
          When do I pay first payment?
        </label>
        <div class="answers">
          You ask me when you pay the first payment? The first payment is the "three plus" initial rental amount of your contract. This is usually paid just after delivery of your new car, by direct debit from your bank. Occasionally, it needs to be paid just before delivery. There may be an administration charge that needs paying just before delivery, too. You need to check the deal. Most people have a new car delivered before they pay a single penny.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question42" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question42" class="question">
          I can't afford payments?
        </label>
        <div class="answers">
          You want to know what happens if you can't afford the payments? Well, the contracts are designed to run the full term. They are not supposed to be cancelled, due to the large depreciation on a new car in the first few years. So you need to consider if you can afford the payments over the full term. There are often penalties if you terminate the contract early. But, whatever the case, you will probably need a car, and leasing is about the cheapest way to run a new car.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question43" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question43" class="question">
          Ling's fast-changing prices?
        </label>
        <div class="answers">
          You ask why the prices keep changing so fast? This is because Ling updates her website many times a day with new prices, as she gets them. She often changes prices hundreds of times a day. If you see a good price it's important that you jump fast and grab the deal.
        </div>
      </div>

      <div>
        <input type="checkbox" id="question44" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question44" class="question">
          How do I use Ling's price list?
        </label>
        <div class="answers">
          You want to know how to use Ling's price list? Well, Ling has a massive price list, every day she changes and uploads hundreds of deals, so it can be confusing. She has over 20,000 car deals on her list. So you need to narrow down your search, by entering how many doors, petrol or diesel, price range or A to Z. You can choose auto or manual and the number of years. You'll find all that on her "Price List" tab.
        </div>
      </div>

      <input type="checkbox" id="question45" name="q" class="questions">
      <div class="plus">+</div>
      <label for="question45" class="question">
        Does Ling pay a referral fee?
      </label>
      <div class="answers">
        You ask me if you get paid for referring other customers? Yes! Ling is always happy to reward a customer who refers another person for a car. It all depends on her margin, but she will usually be able to pay a &pound;50 reward for a customer referral, and she will keep this confidential. You can spend this on anything you like.
      </div>

      <div>
        <input type="checkbox" id="question46" name="q" class="questions">
        <div class="plus">+</div>
        <label for="question46" class="question">
          Do I have to pay VAT?
        </label>
        <div class="answers">
          You need to make sure VAT is included in the price if you are a private customer. There are many dodgy companies on the web who deliberately show prices without the VAT, to appear cheaper. All private customers have to pay VAT, it's the law and you can't avoid it, so Ling always includes VAT in all personal contracts. Business customers can claim some of the VAT back. So make sure any prices you compare with include the VAT. Don't be caught out by the dodgy car leasing companies out there.
        </div>
      </div>
  </div>


    <footer id="contact"></footer>

    <?php include 'footer.php'; ?>

  </body>
</html>
