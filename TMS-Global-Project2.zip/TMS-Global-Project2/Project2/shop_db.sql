-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2022 at 03:16 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `plan` tinytext NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `brand`, `description`, `price`, `plan`, `quantity`, `image`) VALUES
(69, 0, 'Seat Arona', 'Seat', 'Hatchback  1.0 Litre • Auto • Petrol', 263, '3+47', 1, 'seat-arona.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `plan` tinytext NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `brand`, `description`, `price`, `plan`, `image`) VALUES
(19, 'Seat Arona', 'Seat', 'Hatchback  1.0 Litre • Auto • Petrol', 263, '3+47', 'seat-arona.jpeg'),
(20, 'Nissan Micra', 'Nissan', 'Hatchback  1.0 Litre • Manual • Petrol', 230, '3+35', 'nissan-micra.jpeg'),
(21, 'Citroen C3', 'Citroen', 'Hatchback  1.2 Litre • Manual • Petrol', 238, '3+35', 'citroen-c3.jpeg'),
(22, 'VW Polo', 'VW', 'Hatchback  1.0 Litre • Manual • Petrol', 252, '3+47', 'vw-polo.jpeg'),
(23, 'Nissan Qashqai', 'Nissan', 'Hatchback  1.3 Litre • Manual • Petrol', 258, '3+47', 'Nissan-Qashqai.jpeg'),
(24, 'VW T-Roc MY22', 'VW', 'Hatchback  1.5 Litre • Manual • Petrol', 285, '3+35', 'vw-troc.jpeg'),
(25, 'Hyundai Tucson', 'Hyundai', 'Estate  1.6 Litre • Manual • Petrol', 322, '3+35', 'hyundai-tucson.jpeg'),
(26, 'Volvo V60', 'Volvo', 'Estate  2.0 Litre • Auto • Petrol', 437, '3+47', 'volvo-v60.jpeg'),
(27, 'Toyota Aygo', 'Toyota', 'Hatchback  1.0 Litre • Manual • Petrol', 249, '3+35', 'toyota-aygo.jpeg'),
(28, 'Suzuki Swift', 'Suzuki', 'Hybrid  1.2 Litre • Manual • Petrol', 279, '3+35', 'suzuki-swift.jpeg'),
(29, 'Vauxhall Astra', 'Vauxhall', 'Hatchback  1.2 Litre • Manual • Petrol', 295, '3+35', 'vauxhall-astra.jpeg'),
(30, 'Fiat 500', 'Fiat', 'Hatchback  1.4 Litre • Manual • Petrol', 348, '3+23', 'fiat-500.jpeg'),
(31, 'MG ZS', 'MG', 'Hatchback  1.5 Litre • Manual • Petrol', 348, '3+11', 'mg-zs.jpeg'),
(32, 'Ford Puma', 'Ford', 'Hatchback  1.0 Litre • Auto • Petrol', 358, '3+11', 'ford-puma.jpeg'),
(33, 'Kia Picanto', 'Kiaa', 'Hatchback  1.0 Litre • Auto • Petrol', 238, '3+11', 'kia-picanto.jpeg'),
(37, 'Kia Sportage', 'Kia', 'Estate  1.6 Litre • Manual • Petrol', 362, '3+11', 'kia-sportage.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(10, 'Admin', 'nakama@gmail.com', '47b7bfb65fa83ac9a71dcb0f6296bb6e', 'admin'),
(11, 'User', 'mfalick@jungemode.site', '47b7bfb65fa83ac9a71dcb0f6296bb6e', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
