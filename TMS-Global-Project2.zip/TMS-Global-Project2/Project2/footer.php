<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="index.php">home</a>
         <a href="about.php">about</a>
         <a href="shop.php">shop</a>
         <a href="contact.php">contact</a>
      </div>

      <div class="box">
         <h3>More Info</h3>
         <a href="tips.php">Tips And Hints</a>
         <a href="faq.php">FAQ'S</a>
         <a href="https://www.lingscars.com/terms.htm">Terms And conditions</a>
         <a href="https://www.lingscars.com/privacy">Privacy Policy</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <p> <i class="fas fa-phone"></i> +866 0241 30 </p>
         <p> <i class="fas fa-phone"></i> +0191 460 9444 </p>
         <p> <i class="fas fa-envelope"></i> Sales@LINGsCARS.Com </p>
         <p> <i class="fas fa-map-marker-alt"></i> MSc IoD, 15 Riverside Studios, Newcastle Business Park </p>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/lingscars/"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://twitter.com/LINGsCARS"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="https://www.instagram.com/lings_cars/?hl=en"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="https://www.youtube.com/channel/UCi6TAJ3dKlkE5PgN62LJpDw"> <i class="fab fa-youtube"></i> youtube </a>
      </div>

   </div>

   <p class="credit"> © Copyright 2022 <span>LINGsCARS.com</span> All rights reserved.</p>

</section>
